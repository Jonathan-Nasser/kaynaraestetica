import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Instagram, Sparkles, Calendar, Gift, Phone } from 'lucide-react';

const links = [
  {
    title: 'Agende sua Avaliação',
    url: '#',
    icon: <Calendar className="mr-3 h-5 w-5" />,
  },
  {
    title: 'Nossos Tratamentos',
    url: '#',
    icon: <Sparkles className="mr-3 h-5 w-5" />,
  },
  {
    title: 'Cartão Presente',
    url: '#',
    icon: <Gift className="mr-3 h-5 w-5" />,
  },
  {
    title: 'Fale Conosco no WhatsApp',
    url: '#',
    icon: <Phone className="mr-3 h-5 w-5" />,
  },
];

const socialLinks = [
  {
    icon: <Instagram className="h-6 w-6" />,
    url: '#',
  },
];

const LinkBioPage = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0, scale: 0.95 },
    visible: {
      y: 0,
      opacity: 1,
      scale: 1,
      transition: {
        type: 'spring',
        stiffness: 120,
        damping: 12,
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>Belle Clinic - Nossos Links</title>
        <meta name="description" content="Acesse nossos links e agende seu momento de beleza." />
      </Helmet>
      <div className="flex min-h-screen w-full items-center justify-center p-4">
        <motion.div
          className="w-full max-w-md"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div 
            className="glass-card flex flex-col items-center rounded-3xl p-8 shadow-lg"
            variants={itemVariants}
          >
            <Avatar className="h-28 w-28 border-4 border-white/50">
              <img  class="aspect-square h-full w-full" alt="Clínica de Estética Belle Clinic" src="https://images.unsplash.com/photo-1684660441016-02ce864d6cfd" />
              <AvatarFallback>BC</AvatarFallback>
            </Avatar>
            <h1 className="mt-5 text-4xl font-bold gradient-text">Belle Clinic</h1>
            <p className="mt-2 text-center text-pink-900/60">
              Sua beleza, nossa paixão. ✨ Cuidando de você em cada detalhe.
            </p>
          </motion.div>

          <motion.div className="mt-6 flex flex-col space-y-4" variants={containerVariants}>
            {links.map((link, index) => (
              <motion.a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                variants={itemVariants}
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  variant="outline"
                  className="w-full justify-center glass-card py-7 text-lg font-semibold text-pink-900/80 hover:bg-white/80 hover:text-pink-900/100 hover:border-pink-200/50 shadow-md"
                >
                  {link.icon}
                  {link.title}
                </Button>
              </motion.a>
            ))}
          </motion.div>

          <motion.div className="mt-8 flex justify-center space-x-8" variants={itemVariants}>
            {socialLinks.map((social, index) => (
              <motion.a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-pink-900/50 hover:text-pink-500"
                whileHover={{ scale: 1.2, y: -3 }}
                whileTap={{ scale: 0.9 }}
                transition={{ type: 'spring', stiffness: 300 }}
              >
                {social.icon}
              </motion.a>
            ))}
          </motion.div>

          <motion.p className="mt-8 text-center text-sm text-pink-900/40" variants={itemVariants}>
            © 2025 Belle Clinic. Todos os direitos reservados.
          </motion.p>
        </motion.div>
      </div>
    </>
  );
};

export default LinkBioPage;