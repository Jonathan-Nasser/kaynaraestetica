import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Award } from 'lucide-react';

const About = () => {
  return (
    <section id="sobre" className="py-20 bg-white/5 backdrop-blur-sm">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Sobre a MarketPro
            </h2>
            <p className="text-lg text-white/80 mb-6">
              Somos uma consultoria especializada em marketing digital com mais de 5 anos de experiência 
              ajudando empresas a crescerem no ambiente digital.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-green-400" />
                <span className="text-white">Estratégias personalizadas para cada cliente</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-green-400" />
                <span className="text-white">Resultados mensuráveis e transparentes</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-green-400" />
                <span className="text-white">Equipe especializada e certificada</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-green-400" />
                <span className="text-white">Suporte contínuo e consultoria estratégica</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <img  
              className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              alt="Equipe de marketing trabalhando em estratégias digitais"
             src="https://images.unsplash.com/photo-1567080185975-88eedc2b273a" />
            <div className="absolute -bottom-6 -right-6 glass-effect rounded-xl p-6">
              <Award className="w-12 h-12 text-yellow-400 mb-2" />
              <div className="text-white font-semibold">Certificados</div>
              <div className="text-white/80 text-sm">Google & Meta</div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;