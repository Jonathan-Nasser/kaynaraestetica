import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: "Maria Silva",
    company: "TechStart",
    text: "A consultoria transformou completamente nossa estratégia de marketing. Aumentamos nossos leads em 300% em apenas 6 meses!",
    rating: 5
  },
  {
    name: "João Santos",
    company: "E-commerce Plus",
    text: "Profissionais excepcionais! Eles entenderam nossa visão e criaram campanhas que realmente convertem.",
    rating: 5
  },
  {
    name: "Ana Costa",
    company: "Startup Inovadora",
    text: "O ROI das nossas campanhas melhorou drasticamente. Recomendo para qualquer empresa que quer crescer.",
    rating: 5
  }
];

const Testimonials = () => {
  return (
    <section id="depoimentos" className="py-20">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            O Que Nossos Clientes Dizem
          </h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            Histórias reais de sucesso e transformação digital
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="glass-effect rounded-2xl p-8"
            >
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-white/90 mb-6 italic">"{testimonial.text}"</p>
              <div>
                <div className="font-semibold text-white">{testimonial.name}</div>
                <div className="text-white/70 text-sm">{testimonial.company}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;