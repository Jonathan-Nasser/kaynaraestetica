import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin, Zap } from 'lucide-react';

const Contact = ({ handleContactClick }) => {
  return (
    <section id="contato" className="py-20 bg-white/5 backdrop-blur-sm">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Vamos Conversar?
          </h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            Entre em contato conosco e descubra como podemos transformar seu negócio
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="flex items-center space-x-4">
              <div className="glass-effect rounded-full p-4">
                <Mail className="w-6 h-6 text-blue-300" />
              </div>
              <div>
                <div className="text-white font-semibold">Email</div>
                <div className="text-white/80">contato@marketpro.com.br</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="glass-effect rounded-full p-4">
                <Phone className="w-6 h-6 text-blue-300" />
              </div>
              <div>
                <div className="text-white font-semibold">Telefone</div>
                <div className="text-white/80">(11) 9999-9999</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="glass-effect rounded-full p-4">
                <MapPin className="w-6 h-6 text-blue-300" />
              </div>
              <div>
                <div className="text-white font-semibold">Endereço</div>
                <div className="text-white/80">São Paulo, SP - Brasil</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="glass-effect rounded-2xl p-8"
          >
            <form className="space-y-6">
              <div>
                <label className="block text-white font-semibold mb-2">Nome</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400"
                  placeholder="Seu nome completo"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2">Email</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400"
                  placeholder="seu@email.com"
                />
              </div>
              <div>
                <label className="block text-white font-semibold mb-2">Mensagem</label>
                <textarea 
                  rows="4"
                  className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400"
                  placeholder="Como podemos ajudar seu negócio?"
                ></textarea>
              </div>
              <Button 
                onClick={handleContactClick}
                type="button"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 text-lg"
              >
                Enviar Mensagem <Zap className="ml-2 w-5 h-5" />
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;