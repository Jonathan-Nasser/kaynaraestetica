import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Target, Users, BarChart3 } from 'lucide-react';

const services = [
  {
    icon: <TrendingUp className="w-8 h-8" />,
    title: "Marketing Digital",
    description: "Estratégias completas para aumentar sua presença online e gerar mais leads qualificados."
  },
  {
    icon: <Target className="w-8 h-8" />,
    title: "Branding & Posicionamento",
    description: "Construímos marcas memoráveis que se conectam com seu público-alvo de forma autêntica."
  },
  {
    icon: <BarChart3 className="w-8 h-8" />,
    title: "Análise de Dados",
    description: "Transformamos dados em insights acionáveis para otimizar suas campanhas de marketing."
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Gestão de Redes Sociais",
    description: "Criamos conteúdo envolvente e gerenciamos sua presença nas principais plataformas sociais."
  }
];

const Services = () => {
  return (
    <section id="servicos" className="py-20">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Nossos Serviços
          </h2>
          <p className="text-xl text-white/80 max-w-3xl mx-auto">
            Oferecemos soluções completas de marketing digital para impulsionar seu negócio
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="glass-effect rounded-2xl p-8 text-center hover:shadow-2xl transition-all duration-300"
            >
              <div className="text-blue-300 mb-4 flex justify-center">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">{service.title}</h3>
              <p className="text-white/80">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;