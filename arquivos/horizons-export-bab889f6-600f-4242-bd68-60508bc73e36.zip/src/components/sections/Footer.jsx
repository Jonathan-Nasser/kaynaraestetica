import React from 'react';

const Footer = () => {
  return (
    <footer className="py-12 bg-black/20 backdrop-blur-sm">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold text-white mb-4">MarketPro</div>
            <p className="text-white/70">
              Transformando negócios através do marketing digital estratégico.
            </p>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Serviços</span>
            <div className="space-y-2">
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Marketing Digital</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Branding</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Análise de Dados</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Redes Sociais</div>
            </div>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Empresa</span>
            <div className="space-y-2">
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Sobre Nós</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Equipe</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Carreiras</div>
              <div className="text-white/70 hover:text-white cursor-pointer transition-colors">Blog</div>
            </div>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Contato</span>
            <div className="space-y-2">
              <div className="text-white/70">contato@marketpro.com.br</div>
              <div className="text-white/70">(11) 9999-9999</div>
              <div className="text-white/70">São Paulo, SP</div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-8 pt-8 text-center">
          <p className="text-white/70">
            © 2025 MarketPro Consultoria. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;