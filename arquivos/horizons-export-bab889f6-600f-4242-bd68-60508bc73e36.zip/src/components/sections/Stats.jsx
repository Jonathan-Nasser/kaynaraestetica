import React from 'react';
import { motion } from 'framer-motion';

const stats = [
  { number: "500+", label: "Clientes Atendidos" },
  { number: "95%", label: "Taxa de Satisfação" },
  { number: "300%", label: "Aumento Médio em Leads" },
  { number: "5 Anos", label: "de Experiência" }
];

const Stats = () => {
  return (
    <section className="py-20 bg-white/5 backdrop-blur-sm">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">{stat.number}</div>
              <div className="text-white/80">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;