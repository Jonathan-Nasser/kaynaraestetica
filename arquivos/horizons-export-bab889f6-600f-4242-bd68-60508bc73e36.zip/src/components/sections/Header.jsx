import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const Header = ({ handleContactClick }) => {
  return (
    <motion.header 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 w-full z-50 glass-effect"
    >
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="text-2xl font-bold text-white"
          >
            MarketPro
          </motion.div>
          <div className="hidden md:flex space-x-8">
            <a href="#inicio" className="text-white hover:text-blue-200 transition-colors">Início</a>
            <a href="#servicos" className="text-white hover:text-blue-200 transition-colors">Serviços</a>
            <a href="#sobre" className="text-white hover:text-blue-200 transition-colors">Sobre</a>
            <a href="#depoimentos" className="text-white hover:text-blue-200 transition-colors">Depoimentos</a>
            <a href="#contato" className="text-white hover:text-blue-200 transition-colors">Contato</a>
          </div>
          <Button 
            onClick={handleContactClick}
            className="bg-white text-blue-600 hover:bg-blue-50 font-semibold"
          >
            Fale Conosco
          </Button>
        </div>
      </nav>
    </motion.header>
  );
};

export default Header;