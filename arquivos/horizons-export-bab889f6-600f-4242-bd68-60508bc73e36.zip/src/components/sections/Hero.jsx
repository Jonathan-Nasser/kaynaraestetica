import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = ({ handleContactClick }) => {
  return (
    <section id="inicio" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20"></div>
      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Transforme Seu
            <span className="block gradient-text">Negócio Digital</span>
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
            Estratégias de marketing personalizadas que geram resultados reais. 
            Aumente suas vendas e fortaleça sua marca com nossa expertise.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleContactClick}
              size="lg" 
              className="bg-white text-blue-600 hover:bg-blue-50 font-semibold text-lg px-8 py-4 pulse-glow"
            >
              Começar Agora <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              onClick={handleContactClick}
              variant="outline" 
              size="lg" 
              className="border-white text-white hover:bg-white hover:text-blue-600 font-semibold text-lg px-8 py-4"
            >
              Saiba Mais
            </Button>
          </div>
        </motion.div>
      </div>
      
      <div className="absolute top-20 left-10 floating-animation">
        <div className="w-20 h-20 bg-white/10 rounded-full backdrop-blur-sm"></div>
      </div>
      <div className="absolute bottom-20 right-10 floating-animation" style={{ animationDelay: '2s' }}>
        <div className="w-16 h-16 bg-white/10 rounded-full backdrop-blur-sm"></div>
      </div>
    </section>
  );
};

export default Hero;