import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import LinkBioPage from '@/pages/LinkBioPage';

function App() {
  return (
    <>
      <div className="aurora-background"></div>
      <Routes>
        <Route path="/" element={<LinkBioPage />} />
      </Routes>
      <Toaster />
    </>
  );
}

export default App;